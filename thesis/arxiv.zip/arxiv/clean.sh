rm -f \
    main.acn \
    main.acr \
    main.alg \
    main.aux \
    main.bbl \
    main.blg \
    main.ist \
    main.lof \
    main.log \
    main.lol \
    main.lot \
    main.out \
    main.pdf \
    main.toc
