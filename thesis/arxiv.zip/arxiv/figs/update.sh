#!/bin/bash
# Microbenchmarks
cp -r ../../../criu-lm/benchmarking/micro-benchmarks/iterative-migration/fig/* iterative-migration-microbenchmark
cp -r ../../../criu-lm/benchmarking/micro-benchmarks/diskless-migration/fig/* diskless-migration-microbenchmark/
cp -r ../../../criu-lm/benchmarking/micro-benchmarks/tcp-established-downtime/fig/* tcp-established-downtime/
cp -r ../../../criu-lm/benchmarking/micro-benchmarks/tcp-established-resolution/fig/* tcp-established-resolution/

# Macrobenchmarks
cp -r ../../../criu-lm/benchmarking/macro-benchmarks/key-scalability/* key-scalability/
cp -r ../../../criu-lm/benchmarking/macro-benchmarks/vm-teleport/fig/* vm-teleport/
cp -r ../../../criu-lm/benchmarking/macro-benchmarks/downtime/* downtime/
